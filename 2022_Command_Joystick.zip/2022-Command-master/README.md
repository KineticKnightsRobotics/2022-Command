# 2022-Command
Kincardine Kinetic Knights FRC Team 781 2022 robot code

The java code for the 2022 Team 781 competition robot

Subsystems

Drive - the drive base for Joystick Drive

AirSyst - operates the solenoid valves

Intake - operates the intake conveyor and the ball elevator

Shooter - operates the two shooter motors
